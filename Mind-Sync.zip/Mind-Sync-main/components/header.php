<header>
    <nav class="navbar">
        <div class="container">
            <div class="logo">
                <h1><i class="fas fa-brain"></i> Mind Sync</h1>
            </div>
            <div class="auth-buttons">
                <a href="logout.php" class="btn btn-primary"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
            <div class="mobile-menu">
                <i class="fas fa-bars"></i>
            </div>
        </div>
    </nav>
</header> 